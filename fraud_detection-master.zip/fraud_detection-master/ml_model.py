

print("adding all ML realted code here")


def model1():
    print("adding code for ML Model1")


def model2():
    print("adding code for ML Model2")

def model3():
    print("adding code for ML Model3")


print("model2 is performing best")
